#ifndef __SSD1306_TEST_H__
#define __SSD1306_TEST_H__

void ssd1306_TestBorder(void);
void ssd1306_TestFonts(void);
void ssd1306_TestFPS(void);
void ssd1306_TestAll(void);

#endif // __SSD1306_TEST_H__
